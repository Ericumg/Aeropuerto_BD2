const oracledb = require('oracledb');

const dbConfig = {
  user: 'AEREOPUERTO',
  password: '123456',
  connectString: 'localhost:1521/orcl'
};

module.exports = dbConfig;

